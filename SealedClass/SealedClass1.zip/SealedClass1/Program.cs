﻿using System;
namespace SealedClass1;
class Program
{
    public static void Main(string[] args)
    {
        //sealed class cannot inherit to other class
    }
}